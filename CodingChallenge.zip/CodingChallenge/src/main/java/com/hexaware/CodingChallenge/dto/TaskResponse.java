package com.hexaware.CodingChallenge.dto;

import com.hexaware.CodingChallenge.entity.Task;
import java.time.LocalDate;

public class TaskResponse {
    
    private Long id;
    private String title;
    private String description;
    private LocalDate dueDate;
    private Task.Priority priority;
    private Task.Status status;
    
    // Default constructor
    public TaskResponse() {}
    
    // Constructor from Task entity
    public TaskResponse(Task task) {
        this.id = task.getId();
        this.title = task.getTitle();
        this.description = task.getDescription();
        this.dueDate = task.getDueDate();
        this.priority = task.getPriority();
        this.status = task.getStatus();
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public LocalDate getDueDate() {
        return dueDate;
    }
    
    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }
    
    public Task.Priority getPriority() {
        return priority;
    }
    
    public void setPriority(Task.Priority priority) {
        this.priority = priority;
    }
    
    public Task.Status getStatus() {
        return status;
    }
    
    public void setStatus(Task.Status status) {
        this.status = status;
    }
} 