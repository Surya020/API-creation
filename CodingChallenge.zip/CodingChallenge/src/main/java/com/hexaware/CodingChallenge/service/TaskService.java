package com.hexaware.CodingChallenge.service;

import com.hexaware.CodingChallenge.dto.TaskRequest;
import com.hexaware.CodingChallenge.dto.TaskResponse;
import com.hexaware.CodingChallenge.entity.Task;
import com.hexaware.CodingChallenge.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TaskService {
    
    @Autowired
    private TaskRepository taskRepository;
    
    // Get all tasks
    public List<TaskResponse> getAllTasks() {
        return taskRepository.findAll()
                .stream()
                .map(TaskResponse::new)
                .collect(Collectors.toList());
    }
    
    // Get task by ID
    public Optional<TaskResponse> getTaskById(Long id) {
        return taskRepository.findById(id)
                .map(TaskResponse::new);
    }
    
    // Create new task
    public TaskResponse createTask(TaskRequest taskRequest) {
        Task task = taskRequest.toTask();
        Task savedTask = taskRepository.save(task);
        return new TaskResponse(savedTask);
    }
    
    // Update existing task
    public Optional<TaskResponse> updateTask(Long id, TaskRequest taskRequest) {
        return taskRepository.findById(id)
                .map(existingTask -> {
                    existingTask.setTitle(taskRequest.getTitle());
                    existingTask.setDescription(taskRequest.getDescription());
                    existingTask.setDueDate(taskRequest.getDueDate());
                    if (taskRequest.getPriority() != null) {
                        existingTask.setPriority(taskRequest.getPriority());
                    }
                    if (taskRequest.getStatus() != null) {
                        existingTask.setStatus(taskRequest.getStatus());
                    }
                    Task updatedTask = taskRepository.save(existingTask);
                    return new TaskResponse(updatedTask);
                });
    }
    
    // Delete task
    public boolean deleteTask(Long id) {
        if (taskRepository.existsById(id)) {
            taskRepository.deleteById(id);
            return true;
        }
        return false;
    }
    
    // Get tasks by status
    public List<TaskResponse> getTasksByStatus(Task.Status status) {
        return taskRepository.findByStatus(status)
                .stream()
                .map(TaskResponse::new)
                .collect(Collectors.toList());
    }
    
    // Get tasks by priority
    public List<TaskResponse> getTasksByPriority(Task.Priority priority) {
        return taskRepository.findByPriority(priority)
                .stream()
                .map(TaskResponse::new)
                .collect(Collectors.toList());
    }
    
    // Search tasks by title
    public List<TaskResponse> searchTasksByTitle(String title) {
        return taskRepository.findByTitleContainingIgnoreCase(title)
                .stream()
                .map(TaskResponse::new)
                .collect(Collectors.toList());
    }
} 