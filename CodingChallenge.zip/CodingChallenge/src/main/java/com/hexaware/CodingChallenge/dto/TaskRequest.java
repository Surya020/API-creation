package com.hexaware.CodingChallenge.dto;

import com.hexaware.CodingChallenge.entity.Task;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public class TaskRequest {
    
    @NotBlank(message = "Title is required")
    private String title;
    
    private String description;
    
    @NotNull(message = "Due date is required")
    private LocalDate dueDate;
    
    private Task.Priority priority;
    
    private Task.Status status;
    
    // Default constructor
    public TaskRequest() {}
    
    // Constructor with parameters
    public TaskRequest(String title, String description, LocalDate dueDate, Task.Priority priority) {
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.priority = priority;
    }
    
    // Getters and Setters
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public LocalDate getDueDate() {
        return dueDate;
    }
    
    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }
    
    public Task.Priority getPriority() {
        return priority;
    }
    
    public void setPriority(Task.Priority priority) {
        this.priority = priority;
    }
    
    public Task.Status getStatus() {
        return status;
    }
    
    public void setStatus(Task.Status status) {
        this.status = status;
    }
    
    // Method to convert to Task entity
    public Task toTask() {
        Task task = new Task(title, description, dueDate, priority);
        if (status != null) {
            task.setStatus(status);
        }
        return task;
    }
} 